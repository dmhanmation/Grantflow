import React, { useState } from 'react';
import { OrgProfile, OrgDepartment, StaffMember, UserRole } from '../types';
import { sortStaffByHierarchy } from '../utils/staffHierarchy';
import { StructuredMultiSelect } from './StructuredMultiSelect';
import { StructuredSingleSelect } from './StructuredSingleSelect';
import {
  STANDARD_THEMATIC_SECTORS,
  STANDARD_COUNTRIES,
  STANDARD_ORG_CLASSIFICATIONS,
  STANDARD_DEPARTMENT_OPTIONS
} from '../data/taxonomyOptions';
import {
  Building2,
  Users,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Plus,
  Trash2,
  ShieldCheck,
  Award,
  Layers,
  Sparkles,
  UserCheck,
  Mail,
  Briefcase,
  HelpCircle,
  Check,
  AlertCircle,
  X
} from 'lucide-react';

interface OnboardingWizardProps {
  initialProfile: OrgProfile;
  adminUser: { fullName: string; email: string };
  onComplete: (completedProfile: OrgProfile) => void;
}

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({
  initialProfile,
  adminUser,
  onComplete
}) => {
  const [step, setStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Step 1: Org Details
  const [name, setName] = useState(initialProfile.name || '');
  const [country, setCountry] = useState(initialProfile.country || '');
  const [registrationStatus, setRegistrationStatus] = useState(initialProfile.registrationStatus || '');
  const [orgType, setOrgType] = useState(initialProfile.orgType || '');
  const [thematicAreas, setThematicAreas] = useState<string[]>(
    initialProfile.thematicAreas?.length > 0 ? initialProfile.thematicAreas : []
  );
  const [newThematic, setNewThematic] = useState('');
  const [contactEmail, setContactEmail] = useState(initialProfile.contactEmail || adminUser.email);

  // Step 2: Departments (no departments are created automatically)
  const [departments, setDepartments] = useState<OrgDepartment[]>(
    Array.isArray(initialProfile.departments) ? initialProfile.departments : []
  );
  const [deptSelection, setDeptSelection] = useState(''); // '' | standard name | 'OTHER'
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptCode, setNewDeptCode] = useState('');

  // Step 3 & 4: Staff & Hierarchy
  const initialAdminStaff: StaffMember = {
    id: `staff-${Date.now()}-admin`,
    fullName: adminUser.fullName,
    email: adminUser.email,
    jobTitle: 'Organisation Admin',
    department: '',
    departmentId: undefined,
    isDepartmentHead: false,
    functionalRole: 'Admin',
    role: 'Admin',
    roles: ['Admin'],
    status: 'Active',
    joinedDate: new Date().toISOString().split('T')[0]
  };

  const [staffDirectory, setStaffDirectory] = useState<StaffMember[]>(
    initialProfile.staffDirectory?.length ? initialProfile.staffDirectory : [initialAdminStaff]
  );

  // New staff input state
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffEmail, setNewStaffEmail] = useState('');
  const [newStaffTitle, setNewStaffTitle] = useState('');
  const [newStaffDeptId, setNewStaffDeptId] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<UserRole>('Officer');

  // Step 5: Final Approver & Small NGO
  const [finalApproverId, setFinalApproverId] = useState<string>(staffDirectory[0]?.id || '');
  const [smallNgoMode, setSmallNgoMode] = useState<boolean>(true);
  const [requireIntermediateReviewer, setRequireIntermediateReviewer] = useState<boolean>(true);

  // Helper functions
  const handleAddThematic = () => {
    if (newThematic.trim() && !thematicAreas.includes(newThematic.trim())) {
      setThematicAreas([...thematicAreas, newThematic.trim()]);
      setNewThematic('');
    }
  };

  const handleRemoveThematic = (tag: string) => {
    setThematicAreas(thematicAreas.filter(t => t !== tag));
  };

  const handleAddDepartment = () => {
    if (!deptSelection) {
      setErrorMsg('Select a department from the list first.');
      return;
    }

    const isCustom = deptSelection === 'OTHER';
    const standard = STANDARD_DEPARTMENT_OPTIONS.find(d => d.name === deptSelection);

    const name = isCustom ? newDeptName.trim() : standard?.name || '';
    const code = isCustom
      ? (newDeptCode.trim() || newDeptName.trim().substring(0, 4).toUpperCase())
      : standard?.code || '';

    if (!name) {
      setErrorMsg('Enter a name for the custom department.');
      return;
    }
    if (departments.some(d => d.name.toLowerCase() === name.toLowerCase())) {
      setErrorMsg(`${name} has already been added.`);
      return;
    }

    setErrorMsg(null);
    setDepartments([
      ...departments,
      {
        id: `dept-${code.toLowerCase() || 'unit'}-${Date.now()}`,
        name,
        code,
        headStaffId: '',
        headStaffName: '',
        mandate: isCustom ? '' : standard?.mandate,
        color: isCustom ? 'indigo' : standard?.color || 'indigo'
      }
    ]);
    setDeptSelection('');
    setNewDeptName('');
    setNewDeptCode('');
  };

  const handleRemoveDepartment = (id: string) => {
    setDepartments(departments.filter(d => d.id !== id));
  };

  const handleAddStaffMember = () => {
    if (!newStaffName.trim() || !newStaffEmail.trim()) {
      setErrorMsg('Staff Name and Email are required.');
      return;
    }
    const targetDept = departments.find(d => d.id === newStaffDeptId);
    if (!targetDept) {
      setErrorMsg('Select a department for this staff member.');
      return;
    }
    setErrorMsg(null);
    const newStaff: StaffMember = {
      id: `staff-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      fullName: newStaffName.trim(),
      email: newStaffEmail.trim().toLowerCase(),
      jobTitle: newStaffTitle.trim() || 'Officer',
      department: targetDept.name,
      departmentId: newStaffDeptId,
      isDepartmentHead: newStaffRole === 'DepartmentHead',
      functionalRole: newStaffRole === 'Admin' ? 'Admin' : newStaffRole === 'DepartmentHead' ? 'DepartmentHead' : newStaffRole === 'ProposalLead' ? 'ProposalLead' : newStaffRole === 'FinalApprover' ? 'FinalApprover' : 'Contributor',
      role: newStaffRole,
      roles: [newStaffRole],
      status: 'Active',
      joinedDate: new Date().toISOString().split('T')[0]
    };

    setStaffDirectory([...staffDirectory, newStaff]);
    setNewStaffName('');
    setNewStaffEmail('');
    setNewStaffTitle('');
  };

  const handleRemoveStaffMember = (id: string) => {
    if (staffDirectory.length <= 1) {
      setErrorMsg('At least one staff member (the Administrator) is required.');
      return;
    }
    setStaffDirectory(staffDirectory.filter(s => s.id !== id));
  };

  const handleUpdateStaff = (id: string, updates: Partial<StaffMember>) => {
    setStaffDirectory(staffDirectory.map(s => (s.id === id ? { ...s, ...updates } : s)));
  };

  const handleCompleteSetup = async () => {
    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      const selectedApprover = staffDirectory.find(s => s.id === finalApproverId) || staffDirectory[0];

      // Update Department Heads in department list
      const enrichedDepartments = departments.map(d => {
        const head = staffDirectory.find(s => s.departmentId === d.id && (s.isDepartmentHead || s.role === 'DepartmentHead'));
        return {
          ...d,
          headStaffId: head?.id || '',
          headStaffName: head?.fullName || ''
        };
      });

      const completed: OrgProfile = {
        ...initialProfile,
        name: name.trim(),
        country,
        registrationStatus,
        orgType,
        thematicAreas,
        geographicAreas: [country],
        departments: enrichedDepartments,
        staffDirectory,
        defaultFinalApproverId: selectedApprover.id,
        defaultFinalApproverName: selectedApprover.fullName,
        smallNgoMode,
        requireIntermediateReviewer,
        contactEmail: contactEmail.trim().toLowerCase(),
        onboardingComplete: true,
        isDemo: false,
        updatedAt: new Date().toISOString()
      };

      onComplete(completed);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Failed to complete setup.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center py-10 px-4 sm:px-6">
      {/* Brand Header */}
      <div className="text-center mb-8 space-y-2 max-w-xl">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-indigo-600 text-white shadow-xl mb-2">
          <Sparkles className="w-6 h-6" />
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">
          Welcome to GrantFlow
        </h1>
        <p className="text-sm text-slate-300">
          Set up your organization workspace, departments, and proposal approval hierarchy in 5 simple steps.
        </p>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200/80 w-full max-w-3xl overflow-hidden flex flex-col">
        {/* Progress Bar — dependency-ordered stages */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between gap-1 mb-2">
            {['Organisation', 'Departments', 'Staff', 'Roles', 'Governance'].map((label, idx) => {
              const stageNum = idx + 1;
              const isDone = stageNum < step;
              const isCurrent = stageNum === step;
              return (
                <React.Fragment key={label}>
                  <button
                    type="button"
                    onClick={() => { if (stageNum < step) { setErrorMsg(null); setStep(stageNum); } }}
                    disabled={stageNum > step}
                    className={`flex items-center gap-1.5 text-[11px] font-bold whitespace-nowrap transition ${
                      isCurrent ? 'text-indigo-600' : isDone ? 'text-emerald-600 hover:text-emerald-700' : 'text-slate-400'
                    } ${stageNum < step ? 'cursor-pointer' : 'cursor-default'}`}
                  >
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                      isCurrent ? 'bg-indigo-600 text-white' : isDone ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-500'
                    }`}>
                      {isDone ? <Check className="w-3 h-3" /> : stageNum}
                    </span>
                    <span className="hidden sm:inline">{label}</span>
                  </button>
                  {idx < 4 && <ArrowRight className="w-3 h-3 text-slate-300 shrink-0" />}
                </React.Fragment>
              );
            })}
          </div>
          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-full transition-all duration-300 rounded-full"
              style={{ width: `${(step / 5) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Body */}
        <div className="p-6 sm:p-8 flex-1 space-y-6">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* STEP 1: Details */}
          {step === 1 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Step 1 — Organisation Details</h3>
                <p className="text-xs text-slate-500">Provide basic profile facts used in grant compliance pre-checks.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Organisation Name *
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Enter organisation name"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Country of Primary Operation *
                    </label>
                    <StructuredSingleSelect
                      options={STANDARD_COUNTRIES}
                      selected={country}
                      onChange={setCountry}
                      placeholder="Select primary country..."
                      allowCustom={true}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Registration Status
                    </label>
                    <input
                      type="text"
                      value={registrationStatus}
                      onChange={e => setRegistrationStatus(e.target.value)}
                      placeholder="Enter registration status or number"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Official Contact Email *
                  </label>
                  <input
                    type="email"
                    value={contactEmail}
                    onChange={e => setContactEmail(e.target.value)}
                    placeholder="Enter official contact email"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                    required
                  />
                </div>

                <div>
                  <StructuredMultiSelect
                    label="Core Thematic Areas"
                    options={STANDARD_THEMATIC_SECTORS}
                    selected={thematicAreas}
                    onChange={setThematicAreas}
                    badgeColor="indigo"
                    placeholder="Select core thematic sectors..."
                    allowCustom={true}
                    customPlaceholder="Add custom sector..."
                    helperText="Priority intervention sectors used by GrantFlow to match donor funding calls."
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Departments */}
          {step === 2 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Step 2 — Configure Departments</h3>
                <p className="text-xs text-slate-500">
                  GrantFlow assigns proposal sections and review responsibilities to specific departments.
                </p>
              </div>

              <div className="space-y-3">
                {departments.length === 0 && (
                  <p className="text-[11px] text-slate-500 italic px-1">
                    No departments added yet. Add the units your organisation uses. Staff can only be assigned to departments created here.
                  </p>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-72 overflow-y-auto pr-1">
                  {departments.map(dept => (
                    <div
                      key={dept.id}
                      className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{dept.name}</span>
                          <span className="px-1.5 py-0.5 bg-slate-200 text-slate-700 rounded text-[10px] font-bold">
                            {dept.code}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{dept.mandate}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveDepartment(dept.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition"
                        title="Remove department"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-2">
                  <span className="text-xs font-bold text-indigo-900 block">Add Department</span>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <select
                      value={deptSelection}
                      onChange={e => { setErrorMsg(null); setDeptSelection(e.target.value); }}
                      className="flex-1 px-3 py-1.5 bg-white border border-indigo-200 rounded-lg text-xs font-medium"
                    >
                      <option value="">Select a department...</option>
                      {STANDARD_DEPARTMENT_OPTIONS
                        .filter(d => !departments.some(x => x.name.toLowerCase() === d.name.toLowerCase()))
                        .map(d => (
                          <option key={d.code} value={d.name}>{d.name}</option>
                        ))}
                      <option value="OTHER">Other / Custom Department</option>
                    </select>
                    <button
                      type="button"
                      onClick={handleAddDepartment}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shrink-0 flex items-center justify-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add
                    </button>
                  </div>

                  {deptSelection === 'OTHER' && (
                    <div className="flex gap-2 pt-1 animate-in fade-in duration-150">
                      <input
                        type="text"
                        placeholder="Custom department name"
                        value={newDeptName}
                        onChange={e => setNewDeptName(e.target.value)}
                        className="flex-1 px-3 py-1.5 bg-white border border-indigo-200 rounded-lg text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Code"
                        value={newDeptCode}
                        onChange={e => setNewDeptCode(e.target.value.toUpperCase())}
                        className="w-24 px-3 py-1.5 bg-white border border-indigo-200 rounded-lg text-xs uppercase"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Staff Roster */}
          {step === 3 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Step 3 — Add Initial Staff</h3>
                <p className="text-xs text-slate-500">
                  Add staff members who will contribute to proposals, draft sections, or conduct reviews.
                </p>
              </div>

              {/* Add form — gated on at least one department existing */}
              {departments.length === 0 ? (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <span className="text-xs font-bold text-amber-900 block">Create a department first</span>
                    <p className="text-[11px] text-amber-800 mt-0.5">
                      Staff must be assigned to a department. Add at least one department before adding staff.
                    </p>
                    <button
                      type="button"
                      onClick={() => { setErrorMsg(null); setStep(2); }}
                      className="mt-2 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[11px] font-bold flex items-center gap-1.5"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      Create Department First
                    </button>
                  </div>
                </div>
              ) : (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Add Staff Member
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Full Name"
                    value={newStaffName}
                    onChange={e => setNewStaffName(e.target.value)}
                    className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                  />
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={newStaffEmail}
                    onChange={e => setNewStaffEmail(e.target.value)}
                    className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                  />
                  <input
                    type="text"
                    placeholder="Job Title"
                    value={newStaffTitle}
                    onChange={e => setNewStaffTitle(e.target.value)}
                    className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                  />
                  <select
                    value={newStaffDeptId}
                    onChange={e => setNewStaffDeptId(e.target.value)}
                    className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium"
                  >
                    <option value="">Select department...</option>
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.code})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={handleAddStaffMember}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
                  >
                    <Plus className="w-4 h-4" />
                    Add Staff Member
                  </button>
                </div>
              </div>
              )}

              {/* Staff List */}
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                  Staff Directory ({staffDirectory.length})
                </span>
                {sortStaffByHierarchy(staffDirectory).map((staff, idx) => (
                  <div
                    key={staff.id}
                    className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between gap-3 shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                        {staff.fullName[0]}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{staff.fullName}</span>
                          {idx === 0 && (
                            <span className="px-1.5 py-0.2 bg-indigo-100 text-indigo-800 rounded text-[9px] font-bold">
                              Primary Admin
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {staff.jobTitle} • {staff.department}{staff.email ? <span> • <span className="font-mono">{staff.email}</span></span> : null}
                        </p>
                      </div>
                    </div>

                    {idx > 0 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveStaffMember(staff.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 4: Hierarchy & Roles */}
          {step === 4 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Step 4 — Assign Functional Roles & Hierarchy</h3>
                <p className="text-xs text-slate-500">
                  Assign each staff member their operational role in the proposal workflow.
                </p>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                {staffDirectory.map(staff => (
                  <div
                    key={staff.id}
                    className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <strong className="text-xs text-slate-900 block">{staff.fullName}</strong>
                        <span className="text-[11px] text-slate-500">{staff.jobTitle}</span>
                      </div>
                      <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                        {staff.department}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-200/60 text-xs">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                          Functional Role
                        </label>
                        <select
                          value={staff.role || 'Officer'}
                          onChange={e => {
                            const newRole = e.target.value as UserRole;
                            handleUpdateStaff(staff.id, {
                              role: newRole,
                              roles: [newRole],
                              isDepartmentHead: newRole === 'DepartmentHead',
                              functionalRole: newRole === 'Admin' ? 'Admin' : newRole === 'DepartmentHead' ? 'DepartmentHead' : newRole === 'ProposalLead' ? 'ProposalLead' : newRole === 'FinalApprover' ? 'FinalApprover' : 'Contributor'
                            });
                          }}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold"
                        >
                          <option value="Admin">Organisation Admin</option>
                          <option value="DepartmentHead">Department Head / Line Manager</option>
                          <option value="ProposalLead">Proposal Lead</option>
                          <option value="Officer">Officer / Contributor</option>
                          <option value="FinalApprover">Final Approver</option>
                          <option value="Viewer">Viewer (Read-Only)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                          Department Head / Line Manager
                        </label>
                        <select
                          value={staff.lineManagerId || ''}
                          onChange={e => {
                            const mgr = staffDirectory.find(s => s.id === e.target.value);
                            handleUpdateStaff(staff.id, {
                              lineManagerId: mgr?.id,
                              lineManagerName: mgr?.fullName
                            });
                          }}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                        >
                          <option value="">None / Direct to Executive</option>
                          {staffDirectory
                            .filter(s => s.id !== staff.id)
                            .map(s => (
                              <option key={s.id} value={s.id}>
                                {s.fullName} ({s.jobTitle})
                              </option>
                            ))}
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 5: Final Approver & Small NGO */}
          {step === 5 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Step 5 — Approval Governance & Final Setup</h3>
                <p className="text-xs text-slate-500">
                  Select your senior proposal signatory and customize governance workflows.
                </p>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-2">
                  <label className="block text-xs font-bold text-indigo-950 uppercase tracking-wider">
                    Designated Final Approver (Signatory) *
                  </label>
                  <select
                    value={finalApproverId}
                    onChange={e => setFinalApproverId(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-indigo-200 rounded-xl text-xs font-bold text-slate-900"
                  >
                    {staffDirectory.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.fullName} — {s.jobTitle} ({s.department})
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-indigo-700">
                    This executive or designated leader has final approval authority before grants can be recorded as submitted.
                  </p>
                </div>

                <div className="space-y-3">
                  <label className="flex items-start gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition">
                    <input
                      type="checkbox"
                      checked={smallNgoMode}
                      onChange={e => setSmallNgoMode(e.target.checked)}
                      className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Small NGO Mode (Multi-Role Support)
                      </span>
                      <p className="text-[11px] text-slate-500">
                        Enables lean workflows where single individuals hold multiple responsibilities (e.g. Executive Director as Admin, HoD, and Final Approver).
                      </p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition">
                    <input
                      type="checkbox"
                      checked={requireIntermediateReviewer}
                      onChange={e => setRequireIntermediateReviewer(e.target.checked)}
                      className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Mandatory Departmental HoD Pre-Review
                      </span>
                      <p className="text-[11px] text-slate-500">
                        Enforces that all technical and budget sections must receive Department Head approval before moving to the Proposal Lead.
                      </p>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex items-center justify-between">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => { setErrorMsg(null); setStep(step - 1); }}
              className="px-4 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-xl transition flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
          ) : (
            <div />
          )}

          {step < 5 ? (
            <button
              type="button"
              onClick={() => {
                if (step === 1 && (!name.trim() || !contactEmail.trim())) {
                  setErrorMsg('Organisation Name and Contact Email are required.');
                  return;
                }
                if (step === 2 && departments.length === 0) {
                  setErrorMsg('Add at least one department before continuing to staff.');
                  return;
                }
                setErrorMsg(null);
                setStep(step + 1);
              }}
              className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              Next Step
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleCompleteSetup}
              disabled={isSubmitting}
              className="px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm transition flex items-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>Saving Workspace...</>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  Launch Organisation Workspace
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
